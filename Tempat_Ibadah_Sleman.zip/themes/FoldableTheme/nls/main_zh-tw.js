// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/nls/strings":{_themeLabel:"\u6298\u758a\u5f0f\u4e3b\u984c",_layout_default:"\u9810\u8a2d\u7248\u9762\u914d\u7f6e",_layout_layout1:"\u6392\u7248 1",_localized:{}}});